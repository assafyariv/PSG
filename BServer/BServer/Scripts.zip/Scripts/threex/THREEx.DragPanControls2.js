/** @namespace */
var THREEx	= THREEx 		|| {};

THREEx.DragPanControls2	= function(object, domElement)
{
	this._object	= object;
	this._domElement= domElement || document;

	// parameters that you can change after initialisation
	this.target	= new THREE.Vector3(0, 0, 0);
	this.speedX	= 0.03;
	this.speedY	= 0.03;
	this.rangeX	= -40;
	this.rangeY	= +40;

	// private variables
	this._mouseX	= 0;
	this._mouseY	= 0;
	
	 this.texture_placeholder,
			this.isUserInteracting = false,
			this.onMouseDownMouseX = 0, this.onMouseDownMouseY = 0,
			this.lon = 90, this.onMouseDownLon = 0,
			this.lat = 0, this.onMouseDownLat = 0,
			this.phi = 0, this.theta = 0,
			this.targetT = new THREE.Vector3();

	var _this	= this;
	//this._$onMouseMove	= function(){ _this._onMouseMove.apply(_this, arguments); };
	//this._$onTouchStart	= function(){ _this._onTouchStart.apply(_this, arguments); };
	//this._$onTouchMove	= function(){ _this._onTouchMove.apply(_this, arguments); };

	//this._domElement.addEventListener( 'mousemove', this._$onMouseMove, false );
	//this._domElement.addEventListener( 'touchstart', this._$onTouchStart,false );
	//this._domElement.addEventListener( 'touchmove', this._$onTouchMove, false );
	
	this._$onDocumentMouseDown	= function(){ _this.onDocumentMouseDown.apply(_this, arguments); };
	this._$onDocumentMouseMove	= function(){ _this.onDocumentMouseMove.apply(_this, arguments); };
	this._$onDocumentMouseUp	= function(){ _this.onDocumentMouseUp.apply(_this, arguments); };
	this._$onDocumentMouseWheel	= function(){ _this.onDocumentMouseWheel.apply(_this, arguments); };
	this._$onDocumentTouchStart	= function(){ _this.onDocumentTouchStart.apply(_this, arguments); };
	this._$onDocumentTouchMove	= function(){ _this.onDocumentTouchMove.apply(_this, arguments); };
	
	this._domElement.addEventListener( 'mousedown', this._$onDocumentMouseDown, false );
				this._domElement.addEventListener( 'mousemove', this._$onDocumentMouseMove, false );
				this._domElement.addEventListener( 'mouseup', this._$onDocumentMouseUp, false );
				this._domElement.addEventListener( 'mousewheel', this._$onDocumentMouseWheel, false );

				this._domElement.addEventListener( 'touchstart', this._$onDocumentTouchStart, false );
				this._domElement.addEventListener( 'touchmove', this._$onDocumentTouchMove, false );
}

THREEx.DragPanControls2.prototype.destroy	= function()
{
	//this._domElement.removeEventListener( 'mousemove', this._$onMouseMove, false );
	//this._domElement.removeEventListener( 'touchstart', this._$onTouchStart,false );
	//this._domElement.removeEventListener( 'touchmove', this._$onTouchMove, false );
	
	this._domElement.removeEventListener( 'mousedown', this._$onDocumentMouseDown, false );
				this._domElement.removeEventListener( 'mousemove', this._$onDocumentMouseMove, false );
				this._domElement.removeEventListener( 'mouseup', this._$onDocumentMouseUp, false );
				this._domElement.removeEventListener( 'mousewheel', this._$onDocumentMouseWheel, false );

				this._domElement.removeEventListener( 'touchstart', this._$onDocumentTouchStart, false );
				this._domElement.removeEventListener( 'touchmove', this._$onDocumentTouchMove, false );
}

THREEx.DragPanControls2.prototype._onDocumentMouseDown	= function(event) {
				event.preventDefault();
				isUserInteracting = true;

				onPointerDownPointerX = event.clientX;
				onPointerDownPointerY = event.clientY;

				onPointerDownLon = lon;
				onPointerDownLat = lat;
}

THREEx.DragPanControls2.prototype._onDocumentMouseMove	= function(event) {
				if ( isUserInteracting ) {

					lon = ( onPointerDownPointerX - event.clientX ) * 0.1 + onPointerDownLon;
					lat = ( event.clientY - onPointerDownPointerY ) * 0.1 + onPointerDownLat;
					//render();

				}
}

THREEx.DragPanControls2.prototype._onDocumentMouseUp	= function(event) {
				isUserInteracting = false;
				//render();
}

THREEx.DragPanControls2.prototype._onDocumentMouseWheel	= function(event) {

				//camera.fov -= event.wheelDeltaY * 0.05;
				//camera.updateProjectionMatrix();

				//render();
}

THREEx.DragPanControls2.prototype._onDocumentTouchStart	= function(event) {
				if ( event.touches.length == 1 ) {

					event.preventDefault();

					onPointerDownPointerX = event.touches[ 0 ].pageX;
					onPointerDownPointerY = event.touches[ 0 ].pageY;

					onPointerDownLon = lon;
					onPointerDownLat = lat;

				}

}

THREEx.DragPanControls2.prototype._onDocumentTouchMove	= function(event) {
				if ( event.touches.length == 1 ) {

					event.preventDefault();

					lon = ( onPointerDownPointerX - event.touches[0].pageX ) * 0.1 + onPointerDownLon;
					lat = ( event.touches[0].pageY - onPointerDownPointerY ) * 0.1 + onPointerDownLat;

					//render();

				}

}

THREEx.DragPanControls2.prototype.update	= function(event){

				lat = Math.max( - 85, Math.min( 85, lat ) );
				phi = ( 90 - lat ) * Math.PI / 180;
				theta = lon * Math.PI / 180;

				target.x = 500 * Math.sin( phi ) * Math.cos( theta );
				target.y = 500 * Math.cos( phi );
				target.z = 500 * Math.sin( phi ) * Math.sin( theta );

				camera.lookAt( target );

				renderer.render( scene, camera );

			}

/*			
THREEx.DragPanControls.prototype.update	= function(event)
{
	this._object.position.x += ( this._mouseX * this.rangeX - this._object.position.x ) * this.speedX;
	this._object.position.y += ( this._mouseY * this.rangeY - this._object.position.y ) * this.speedY;
	this._object.lookAt( this.target );
}

THREEx.DragPanControls.prototype._onMouseMove	= function(event)
{
	this._mouseX	= ( event.clientX / window.innerWidth ) - 0.5;
	this._mouseY	= ( event.clientY / window.innerHeight) - 0.5;
}

THREEx.DragPanControls.prototype._onTouchStart	= function(event)
{
	if( event.touches.length != 1 )	return;

	// no preventDefault to get click event on ios

	this._mouseX	= ( event.touches[ 0 ].pageX / window.innerWidth ) - 0.5;
	this._mouseY	= ( event.touches[ 0 ].pageY / window.innerHeight) - 0.5;
}

THREEx.DragPanControls.prototype._onTouchMove	= function(event)
{
	if( event.touches.length != 1 )	return;

	event.preventDefault();

	this._mouseX	= ( event.touches[ 0 ].pageX / window.innerWidth ) - 0.5;
	this._mouseY	= ( event.touches[ 0 ].pageY / window.innerHeight) - 0.5;
}
*/
