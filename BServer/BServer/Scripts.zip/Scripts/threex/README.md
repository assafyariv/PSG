* This should be the root of a git repository but i dunno how to handle submodule

# TODO
* document those
  * you write a lot of code but not a lot of doc
  * all that could go in learningthreejs
  * what about anotated source.
  * easy to write.
  * how to present it in the blog
  * currently anotated source is isnt too embedable
  * should it be a blocker ?
  * likely not
  * make a super simple post for each
* they need example and all
  * how to handle this ?
  * an examples directory like three.js ?
    * why not ?
* how to handle the maturity of it ?
  * many arent too finished